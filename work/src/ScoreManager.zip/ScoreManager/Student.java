package ScoreManager;

public class Student {
	String name;
	int num;
	float socre[]=new float[3];
	float sum;
	
}